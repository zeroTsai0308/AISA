from setuptools import setup


setup(
    name='package_name',
    version='0.1',
    description='Package Description',
    url='https://github.com/yourself/package_name',
    # dependencies
    install_requires=[
    ],
    # python modules
    packages=[
        'package_name',
    ],
)

